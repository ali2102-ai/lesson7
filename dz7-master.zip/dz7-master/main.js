const orders = [
    {
        id: 1,
        customer: "Jhon",
        items: [
            { name: "Ноутбук", price: 50000, quantity: 1 },
            { name: "Мышь", price: 1500, quantity: 2 }
        ]
    },
    {
        id: 2,
        customer: "Alan",
        items: [
            { name: "Телефон", price: 30000, quantity: 1 },
            { name: "Чехол", price: 1000, quantity: 3 }
        ]
    },
    {
        id: 3,
        customer: "Jane",
        items: [
            {name: "Клавиатура", price: 2500, quantity: 1},
            {name: "Монитор", price: 12000, quantity: 1}
        ]
    }
];

for (var j = 0; j < orders.length; j++) {
    var orderSum = 0;
    var items = orders[j].items;

    for (var k = 0; k < items.length; k++) {
        const element = items[k];
        orderSum += element.price * element.quantity;
    }

    console.log(`Заказ ${orders[j].id} (${orders[j].customer}): ${orderSum} сом`);
}